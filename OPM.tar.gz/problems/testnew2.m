function ok = testnew2( pname )

problem = str2func( pname);

x0             = problem( 'setup', 64 );
[ f, g, H]     = problem( 'objf', x0 );
cpsstr         = problem( 'cpsstr', length(x0) );
[ f, g, H]     = problem( 'objf', x0, cpsstr );
[ f1, g1, H1 ] = problem( 'elobjf', 1, x0(cpsstr.eldom{1}), cpsstr.param{:} );

disp( [ ' problem ', pname, ' OK!' ] )
